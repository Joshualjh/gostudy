# gorm install
go get -u gorm.io/gorm

# gin-gonic install
go get -u github.com/gin-gonic/gin

# start go file
go run .\main.go